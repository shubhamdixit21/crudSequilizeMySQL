module.exports = {
    database: "classtest",
    port: 3306,
    host: "localhost",
    user: "root",
    password: ""
}